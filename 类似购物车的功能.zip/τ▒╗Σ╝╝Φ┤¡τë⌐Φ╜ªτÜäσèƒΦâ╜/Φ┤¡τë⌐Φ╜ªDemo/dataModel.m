//
//  dataModel.m
//  购物车Demo
//
//  Created by CuiJianZhou on 15/12/24.
//  Copyright © 2015年 CJZ. All rights reserved.
//

#import "dataModel.h"

@implementation dataModel

- (id)initWithDictionary:(NSDictionary *)dictionary {
    
    if (self = [super init]) {
        
        [self setValuesForKeysWithDictionary:dictionary];
    }
    
    return self;
}

@end

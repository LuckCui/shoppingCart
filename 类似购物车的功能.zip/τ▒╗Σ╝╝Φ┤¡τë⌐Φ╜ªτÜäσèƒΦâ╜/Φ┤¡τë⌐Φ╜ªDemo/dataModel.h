//
//  dataModel.h
//  购物车Demo
//
//  Created by CuiJianZhou on 15/12/24.
//  Copyright © 2015年 CJZ. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface dataModel : NSObject

@property (nonatomic, copy) NSString *title;
@property (nonatomic, copy) NSString *sonTitle;
@property (nonatomic, copy) NSString *imageUrl;
@property (nonatomic, copy) NSString *num;
@property (nonatomic) BOOL isSelected;

- (id)initWithDictionary:(NSDictionary *)dictionary;

@end

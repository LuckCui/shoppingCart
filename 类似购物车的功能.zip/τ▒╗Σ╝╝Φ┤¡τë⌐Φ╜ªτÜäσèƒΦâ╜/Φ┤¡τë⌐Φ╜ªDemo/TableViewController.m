//
//  TableViewController.m
//  购物车Demo
//
//  Created by CuiJianZhou on 15/12/24.
//  Copyright © 2015年 CJZ. All rights reserved.
//

#import "TableViewController.h"
#import "dataModel.h"
#import "UIImageView+WebCache.h"
#import "TableViewCell.h"
#import "CJZAccountController.h"

@interface TableViewController ()<UITableViewDataSource, UITableViewDelegate>
/**
 *  模型数组
 */
@property (nonatomic, strong) NSMutableArray *modelArray;

/**
 *  点击cell选中的数据数组
 */
@property (nonatomic, strong) NSMutableArray *selectedDataArray;
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet UIBarButtonItem *button;
@property (weak, nonatomic) IBOutlet UILabel *price;

@end

@implementation TableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self loadData];
     self.tableView.rowHeight = 60;
    
}

/**
 *  数据
 */
- (void)loadData {
    
    _modelArray = [NSMutableArray array];
    
    NSMutableArray *dataArray = [NSMutableArray array];
    
    NSString *path = [[NSBundle mainBundle]pathForResource:@"HomeHuaDong" ofType:@"plist"];
    dataArray = [NSMutableArray arrayWithContentsOfFile:path];
    
    [dataArray enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        
        dataModel *model = [[dataModel alloc]initWithDictionary:obj];
        
        [_modelArray addObject:model];
        
    }];
}

#pragma mark ========点击全选按钮==========

- (IBAction)buttonClick:(UIBarButtonItem *)sender {
    
    [self.selectedDataArray removeAllObjects];
    
    if ([sender.title isEqualToString:@"全选"]) {
        
        sender.title = @"取消";
        
        [_modelArray enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            
            dataModel *model = obj;
            model.isSelected = YES;
            [self.selectedDataArray addObject:model];
            
        }];
        
        [self summationWithDataArray:self.selectedDataArray];
        [self.tableView reloadData];
        
        
    } else {
        
        sender.title = @"全选";

        [_modelArray enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            
            dataModel *model = obj;
            model.isSelected = NO;
        }];
        
        [self summationWithDataArray:self.selectedDataArray];
        [self.tableView reloadData];

    }
}

#pragma mark - Table view data source

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return self.modelArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *ID = @"cell";
    
    TableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:ID forIndexPath:indexPath];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.imageV.userInteractionEnabled = YES;
    cell.imageV.tag = indexPath.row;
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(didImageView:)];
    [cell.imageV addGestureRecognizer:tap];
    cell.model = _modelArray[indexPath.row];
    
    return cell;
    
}

#pragma mark ========= 去结账 ============

- (IBAction)goAccount:(UIButton *)sender {
    
    [self performSegueWithIdentifier:@"go" sender:self.price.text];
}

//根据线的标识跳转
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    
    if ([segue.identifier isEqualToString:@"go"]) {
    
        CJZAccountController *vc = segue.destinationViewController;
        
        vc.price = sender;
    }

}

#pragma mark ============ 点击选择的方法 ===========（重点）

- (void)didImageView:(UITapGestureRecognizer *)tap {
    
    UIImageView *imageV = (UIImageView *)tap.view;
    //拿出当前点击的数据模型
    dataModel *model = _modelArray[imageV.tag];
    //改变当前数据模型的BOOL值属性（是否选中：取反）
    model.isSelected = !model.isSelected;
    //刷新tableView
    [self.tableView reloadData];
    
    [self.selectedDataArray removeAllObjects];
    
    [_modelArray enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        dataModel *model = obj;
        if (model.isSelected == YES) {
            [_selectedDataArray addObject:model];
        }
    }];
    
    [self summationWithDataArray:_selectedDataArray];
    
    if (self.selectedDataArray.count == self.modelArray.count) {
        
        [self.button setTitle:@"取消"];
    } else {
        [self.button setTitle:@"全选"];

    }
    
}

#pragma mark ==== 计算价钱的方法 =============

- (void)summationWithDataArray:(NSMutableArray *)array {
    
    NSInteger numCount = 0;
    for (int i = 0; i < array.count; i++) {
        
        dataModel *model = array[i];
        NSInteger n = [model.num integerValue];
        numCount = numCount + n;
    }
    
    self.price.text = [NSString stringWithFormat:@"￥%ld元",numCount];
    
}

#pragma maek =============懒加载===================

/**
 * 选中的模型数组
 */
- (NSMutableArray *)selectedDataArray {
    
    if (_selectedDataArray == nil) {
        
        _selectedDataArray = [NSMutableArray array];
    }
    return _selectedDataArray;
}

@end

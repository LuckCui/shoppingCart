//
//  TableViewCell.m
//  购物车Demo
//
//  Created by CuiJianZhou on 15/12/24.
//  Copyright © 2015年 CJZ. All rights reserved.
//

#import "TableViewCell.h"
#import "UIImageView+WebCache.h"

@interface TableViewCell ()


@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UILabel *sonTitleLabel;
@property (weak, nonatomic) IBOutlet UILabel *num;

@end

@implementation TableViewCell

- (void)setModel:(dataModel *)model {
    
    _model = model;
    
    self.titleLabel.text    = model.title;
    self.sonTitleLabel.text = model.sonTitle;
    self.num.text           = model.num;
    NSURL *url = [NSURL URLWithString:model.imageUrl];
    [self.iconView sd_setImageWithURL:url];
    self.imageV.image = _model.isSelected ? [UIImage imageNamed:@"ic_checkbox_pressed"] : [UIImage imageNamed:@"ic_checkbox_normal"];
    

}

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end

//
//  CJZAccountController.h
//  购物车Demo
//
//  Created by CuiJianZhou on 15/12/30.
//  Copyright © 2015年 CJZ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CJZAccountController : UIViewController

@property (copy, nonatomic) NSString *price;

@end

//
//  TableViewCell.h
//  购物车Demo
//
//  Created by CuiJianZhou on 15/12/24.
//  Copyright © 2015年 CJZ. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "dataModel.h"

@interface TableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIImageView *imageV;
@property (weak, nonatomic) IBOutlet UIImageView *iconView;
@property (strong, nonatomic) dataModel *model;

@end
